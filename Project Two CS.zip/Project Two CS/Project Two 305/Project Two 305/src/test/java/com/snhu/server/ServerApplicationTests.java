package com.snhu.server;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.snhu.sslserver.ServerApplication;

@SpringBootTest(classes = ServerApplication.class)
class ServerApplicationTests {

	   @Test
	    public void testSHAChecksum() {
	        String input = "Jacob Osbrach";
	        String expectedChecksum = "d8f563ddd00bdcc7a83d1f455b6bd3744b336f6b4c4fc1f947f4ab31909ad62a"; // checks to see if hashes match
	        String actualChecksum = ServerApplication.of(input);
	        assertEquals(expectedChecksum, actualChecksum);
	    }

}
